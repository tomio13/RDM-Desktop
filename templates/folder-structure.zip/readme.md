#  folder name - project full name
Please describe the project shortly here...

# Abbreviated name

# Description
- Principal investigator:
- Othe authors:
  - ...
- project website (test2folders):
- submission date:
- starting date:
- end date:
- funding agency:
- cooperating partners:
  - ...

created: YYYY-MM-DD
created by: 
